using System;
class HelloWorld
{
static void Main()
{
       
       Console.WriteLine("Hello world");
      
       Console.ReadKey();
}
}